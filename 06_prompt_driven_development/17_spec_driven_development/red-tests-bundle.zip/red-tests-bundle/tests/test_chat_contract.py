from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_chat_missing_user_message_returns_400_top_level_error_code():
    # Missing user_message should be treated as an error per the spec
    payload = {"session_id": "spec-red-1"}
    res = client.post("/chat", json=payload)
    # Spec: 400 with top-level {"error_code": "MISSING_USER_MESSAGE"}
    assert res.status_code == 400
    body = res.json()
    assert isinstance(body, dict)
    assert body.get("error_code") == "MISSING_USER_MESSAGE", (
        "Error body must expose a TOP-LEVEL 'error_code' per spec "
        "(not nested under 'detail')."
    )

def test_chat_happy_path_returns_chatreply_shape():
    payload = {"session_id": "spec-green-1", "user_message": "Hello there!"}
    res = client.post("/chat", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert isinstance(data, dict)
    # Required fields per ChatReply contract
    assert "text" in data
    assert "handoff" in data
    # Optional field
    assert "used_tool" in data