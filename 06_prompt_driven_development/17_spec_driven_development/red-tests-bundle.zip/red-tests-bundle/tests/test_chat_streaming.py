from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_streaming_sends_event_stream_headers():
    headers = {"Accept": "text/event-stream"}
    payload = {"session_id": "sse-1", "user_message": "Stream this please"}
    res = client.post("/chat", json=payload, headers=headers, stream=True)
    # Expect SSE content type start
    assert res.status_code == 200
    ctype = res.headers.get("content-type", "")
    assert "text/event-stream" in ctype.lower(), f"Expected SSE content-type, got: {ctype}"

def test_streaming_emits_at_least_one_data_line_and_done():
    headers = {"Accept": "text/event-stream"}
    payload = {"session_id": "sse-2", "user_message": "Stream another one"}
    with client.stream("POST", "/chat", json=payload, headers=headers) as res:
        assert res.status_code == 200
        chunks = []
        for chunk in res.iter_text():
            if chunk:
                chunks.append(chunk)
                # Don't read forever in case of bug
                if len(chunks) > 200:
                    break
        body = "".join(chunks)
        assert "data:" in body, "SSE body should include at least one 'data:' line"
        assert "data:[DONE]" in body, "SSE should terminate with 'data:[DONE]'"