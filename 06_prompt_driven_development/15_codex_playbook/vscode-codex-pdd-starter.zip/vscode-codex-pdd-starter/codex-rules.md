
# VS Code + Codex — Prompting House Rules

Project guardrails
- Python 3.12+, uv for deps (pyproject + uv.lock)
- Use OpenAI Agents SDK for agents/tools/sessions/handoffs/guardrails
- FastAPI with /healthz and /chat
- Tests first (pytest), offline by default; minimal diffs
- Pydantic structured outputs; reply length ≤ 1200 chars
- No secrets in code or prompts; use .env / .env.sample
- Docker: uv multi-stage; non-root image

Documentation & governance
- PHRs in docs/prompts (architect/red/green/refactor/explainer)
- ADRs in docs/adr for consequential choices
- PRs link PHRs + ADRs; CI runs ruff + pytest; “no green, no merge”

Agent defaults
- CustomerAgent primary; add ResearchAgent via intent handoff
- Tools: calculator(expression), now(tz?)
- Sessions per session_id; SSE streaming with JSON fallback

Change policy
- Touch only the files listed in each prompt; keep diffs minimal
- If tests break, propose a fix-only diff
- Explain changes in ≤8 bullets per slice
