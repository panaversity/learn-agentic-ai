
# VS Code + Codex PDD Starter (2025)

Minimal starter for Prompt-Driven Development (PDD) with OpenAI Codex in VS Code, plus TDD, ADRs, PHRs, uv deps, and optional EDD (promptfoo).

## Quickstart
```bash
uv venv && source .venv/bin/activate
uv sync
uv run pytest -q
uv run uvicorn app.main:app --host 0.0.0.0 --port 8000
curl -s http://localhost:8000/healthz
```
