
# PR Title

## Summary
What changed and why.

## Prompt History (PHR)
- docs/prompts/00xx-*-architect.prompt.md
- docs/prompts/00xx-*-red.prompt.md
- docs/prompts/00xx-*-green.prompt.md

## ADRs
- docs/adr/00yy-*.md

## Test Plan
Commands, screenshots, curl.

## Risks & Rollback
Risks; how to rollback.

## Checklist
- [ ] Small diff
- [ ] CI green (ruff + pytest)
- [ ] ADR linked (if consequential)
- [ ] No secrets
