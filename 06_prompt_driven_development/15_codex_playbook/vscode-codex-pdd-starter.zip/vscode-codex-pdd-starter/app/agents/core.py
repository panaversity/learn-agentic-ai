
from typing import Any, Dict

_SESSIONS: Dict[str, Dict[str, Any]] = {}

def get_session(session_id: str) -> Dict[str, Any]:
    return _SESSIONS.setdefault(session_id, {})

def get_customer_agent() -> Any:
    raise NotImplementedError("Wire OpenAI Agents SDK here during green step")

def get_runner() -> Any:
    raise NotImplementedError("Return a streaming-capable Runner here")
