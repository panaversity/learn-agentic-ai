
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from app.guards.schemas import ChatReply

app = FastAPI(title="VS Code + Codex PDD Starter")

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

class ChatIn(BaseModel):
    session_id: str
    user_message: str | None = None

@app.post("/chat", response_model=ChatReply)
def chat(payload: ChatIn):
    if not payload.user_message:
        raise HTTPException(status_code=400, detail={"error_code": "MISSING_USER_MESSAGE"})
    return ChatReply(text="Hello!", used_tool=None, handoff=False)
