
from pydantic import BaseModel
from typing import Optional

class ChatReply(BaseModel):
    text: str
    used_tool: Optional[str] = None
    handoff: bool = False
