
# PR: Bootstrap service + /chat contract (non-streaming) — Red → Green

## Summary
Scaffold FastAPI, add /healthz, /chat (stub), tests (RED→GREEN). Includes PHR/ADR templates and VS Code tasks.

## PHR
- docs/prompts/0000-template.prompt.md

## Test Plan
- `uv run pytest -q`
- `curl -s localhost:8000/healthz`
