
# ADR-0000: <title>
- **Status:** Draft
- **Date:** YYYY-MM-DD

## Context
What problem are we solving?

## Options
- Option A (pros/cons)
- Option B (pros/cons)

## Decision
Chosen option and why.

## Consequences
Impact and follow-ups.

## References
PHRs/PRs/docs.
