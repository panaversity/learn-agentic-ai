import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_chat_missing_user_message_returns_400():
    # Red test: endpoint not implemented yet -> should fail until /chat exists with validation
    payload = {"session_id": "sess-1"}  # no user_message
    res = client.post("/chat", json=payload)
    assert res.status_code == 400
    body = res.json()
    assert body.get("error_code") == "MISSING_USER_MESSAGE"

def test_chat_happy_path_returns_chatreply_shape():
    # Red test: expects a minimal contract: {text, used_tool?, handoff}
    payload = {"session_id": "sess-1", "user_message": "hello"}
    res = client.post("/chat", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert set(data.keys()) >= {"text", "handoff"}
    assert isinstance(data["text"], str)
    assert isinstance(data["handoff"], bool)
