# Core wiring for Agents SDK (stubs).
# Expose:
# - get_customer_agent(): returns a configured CustomerAgent
# - get_runner(): returns a Runner configured for streaming
# - get_session(session_id): in-memory session store
# Implementations are left for the 'green' PDD step.

from typing import Any, Dict

_SESSIONS: Dict[str, Dict[str, Any]] = {}

def get_session(session_id: str) -> Dict[str, Any]:
    """Return a mutable session dict for the given session_id (stub)."""
    return _SESSIONS.setdefault(session_id, {})

def get_customer_agent() -> Any:  # replace Any with actual Agent type when implemented
    """Return a configured CustomerAgent (stub)."""
    raise NotImplementedError("Implement in green step using OpenAI Agents SDK")

def get_runner() -> Any:  # replace Any with actual Runner type when implemented
    """Return a streaming-capable Runner (stub)."""
    raise NotImplementedError("Implement in green step using OpenAI Agents SDK")
