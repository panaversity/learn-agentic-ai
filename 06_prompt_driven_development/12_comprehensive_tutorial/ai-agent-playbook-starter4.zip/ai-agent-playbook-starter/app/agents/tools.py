# Function tools stubs for the agent (calculator, now).
# Implement using the Agents SDK function_tool decorator during the green step.

from typing import Optional

def calculator(expression: str) -> str:
    """Stub: evaluate a simple expression safely (to be implemented)."""
    raise NotImplementedError

def now(tz: Optional[str] = None) -> str:
    """Stub: return ISO datetime string (to be implemented)."""
    raise NotImplementedError
