# ResearchAgent stub and handoff notes.
# Implement an agent specialized in background research/summarization.

INSTRUCTIONS = (
    "You perform focused background research and return concise findings in bullet points."
)

def should_handoff(user_intent: str, confidence: float) -> bool:
    """Naive policy stub for when to hand off to ResearchAgent."""
    return user_intent.upper() == "RESEARCH" and confidence >= 0.7
