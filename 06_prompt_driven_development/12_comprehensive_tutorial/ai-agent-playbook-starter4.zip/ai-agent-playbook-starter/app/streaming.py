# Helpers for SSE streaming (stub).
from typing import Iterable

def to_sse(chunks: Iterable[str]):
    """Yield Server-Sent Event formatted lines for each chunk (stub)."""
    for c in chunks:
        yield f"data:{c}\n\n"
