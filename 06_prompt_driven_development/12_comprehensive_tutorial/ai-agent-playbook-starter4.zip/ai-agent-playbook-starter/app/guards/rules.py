# Guardrail stubs: basic length/shape checks to be invoked by the agent pipeline.
from .schemas import ChatReply

MAX_LEN = 1200

def validate_reply(reply: ChatReply) -> ChatReply:
    """Raise ValueError if reply violates simple constraints (stub)."""
    if not reply.text or len(reply.text) > MAX_LEN:
        raise ValueError("invalid reply length")
    return reply
