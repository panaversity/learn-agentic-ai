# Basic config loader stub using environment variables.
from pydantic import BaseModel
import os

class Settings(BaseModel):
    model: str = os.getenv("MODEL", "gpt-5")
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")

settings = Settings()
