# AI Agent Playbook Starter (PDD × TDD × ADR × PR)
Generated: 2025-09-21

This repo is intentionally minimal. You will build features via **Cursor** prompts and record them as **Prompt History Records (PHRs)** alongside **ADRs**.

## Quick start
```bash
# Python & deps (uv) — feel free to replace with your manager
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install --upgrade pip

git init
git config core.hooksPath .githooks
chmod +x .githooks/* scripts/*.py

make prompt-new SLUG=setup STAGE=architect
make prompt-index
```

## Recommended Flow
1. Open this folder in **Cursor**.
2. Paste the prompts from the tutorial.
3. Accept small diffs only; keep tests offline.
4. Commit each slice; open a PR; link PHR + ADR.

## Layout
- `app/` — Python package (FastAPI entry at `app/main.py`)
- `app/agents/` — agent factories, tools, runners
- `app/guards/` — Pydantic schemas & guardrails
- `tests/` — start with healthz + contract tests
- `docs/adr/` — Architecture Decision Records
- `docs/prompts/` — Prompt History Records (PHR-####)
- `docs/diagrams/` — mermaid stubs you can edit
- `scripts/` — PHR helper scripts
- `.githooks/` — hooks to encourage prompt discipline

See `docs/TUTORIAL-ITERATIONS.md` for step-by-step examples.


## Docker
Build and run locally:
```bash
docker build -t ai-agent-playbook:dev .
docker run --rm -p 8000:8000 --env-file .env.sample ai-agent-playbook:dev
curl -s http://localhost:8000/healthz
```


## First Iterations (Red → Green)
Run tests; you'll see failures for /chat and SSE. Use Cursor prompts from `docs/TUTORIAL-ITERATIONS.md`:

```bash
pytest -q
# Expect failing tests:
# - tests/test_chat_contract.py::test_chat_missing_user_message_returns_400
# - tests/test_chat_contract.py::test_chat_happy_path_returns_chatreply_shape
# - tests/test_chat_streaming.py::test_chat_streaming_sse_headers_and_events
```

Next:
1) PHR-0005 (architect) for /chat contract
2) PHR-0006 (red) already present (these tests)
3) PHR-0007 (green) minimal /chat to pass tests
4) PHR-0009..0011 for SSE (architect → red → green)
