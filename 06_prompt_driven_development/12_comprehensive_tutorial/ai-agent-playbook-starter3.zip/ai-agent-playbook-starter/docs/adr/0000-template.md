# ADR-0000: <Title>
- **Status:** Proposed | Accepted | Superseded | Deprecated
- **Date:** YYYY-MM-DD

## Context
<Problem, constraints, forces>

## Options
- **A)** ... (pros/cons)
- **B)** ...

## Decision
<Chosen option and why>

## Consequences
- Positive: ...
- Negative: ...

## References
- Links to PRs, issues, benchmarks
- Related Prompts: PHR-####, PHR-####
