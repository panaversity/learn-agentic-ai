# PR Title (concise, imperative)

## Summary
What changed and why? Link to issue if applicable.

## Prompt History (PHR)
- Architect: docs/prompts/00xx-*-architect.prompt.md
- Red: docs/prompts/00xx-*-red.prompt.md
- Green: docs/prompts/00xx-*-green.prompt.md
- Explainer (optional): docs/prompts/00xx-*-explainer.prompt.md

## ADRs
- docs/adr/00yy-*.md

## Test Plan
- Commands run (e.g., `pytest -q`, curl examples)
- Screenshots/logs if applicable

## Risks & Rollback
- Risks introduced
- Rollback strategy

## Checklist
- [ ] Small, focused diff
- [ ] Tests added/updated; CI green
- [ ] ADR linked for consequential decisions
- [ ] No secrets in code or prompts
