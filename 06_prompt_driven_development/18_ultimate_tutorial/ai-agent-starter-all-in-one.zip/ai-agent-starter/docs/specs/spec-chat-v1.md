# Spec: Chat Endpoint (v1)
Version: v1
Status: Accepted
Owner: Platform Team
Linked ADRs: [ADR-0002: streaming-protocol-choice (planned)]

## 1) Scope & Outcomes
- Minimal chat endpoint that accepts `session_id` and `user_message`, returns structured reply.
- In-memory sessions per `session_id` for v1.
- Non-goals: auth, rate limiting, DB persistence, tracing.

## 2) Interfaces & Contracts
**Endpoint**
- POST /chat with JSON: { "session_id": str, "user_message": str }

**Response**
- ChatReply: { "text": str, "used_tool"?: str|null, "handoff": bool }

**Errors**
- 400 with TOP-LEVEL body: { "error_code": "MISSING_USER_MESSAGE" } when `user_message` missing/empty.
- Content-Type: application/json.

## 3) Agent Behavior & Policies
- Primary agent: CustomerAgent; concise; ≤1200 chars.
- Tool-first policy for math/time: `calculator`, `now`.
- Guardrails: output validated against ChatReply; retry once on validation failure then friendly error.

## 4) Acceptance (Tests)
- test_chat_missing_user_message_returns_400_top_level_error_code
- test_chat_happy_path_returns_chatreply_shape

## 5) Ops & Constraints
- Offline tests (mock external calls).
- Secrets via .env; none in code/prompts.

## 6) Change Control
- PR links PHRs + ADRs; CI gates: ruff + pytest (+ EDD smoke if enabled).

*Last updated: 2025-09-22*