
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_streaming_sends_event_stream_headers():
    headers = {"Accept": "text/event-stream"}
    res = client.post("/chat", json={"session_id": "sse-1", "user_message": "Stream this"}, headers=headers, stream=True)
    # Will fail until SSE streaming is implemented
    assert res.status_code == 200
    assert "text/event-stream" in res.headers.get("content-type", "").lower()

def test_streaming_emits_at_least_one_data_line_and_done():
    headers = {"Accept": "text/event-stream"}
    with client.stream("POST", "/chat", json={"session_id": "sse-2", "user_message": "Stream now"}, headers=headers) as res:
        assert res.status_code == 200
        body = "".join(list(res.iter_text()))
        assert "data:" in body
        assert "data:[DONE]" in body
