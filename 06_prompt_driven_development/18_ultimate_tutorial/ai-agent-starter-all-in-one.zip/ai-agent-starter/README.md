
# AI Agent Starter (SDD × PDD × TDD × EDD)
Use in **VS Code + Codex** or **Cursor**. Specs, PHRs, ADRs, tests, EDD, CI, Docker—ready to run.

## Quickstart
```bash
uv venv && source .venv/bin/activate
uv sync
uv run pytest -q            # expect SSE tests to fail (RED) until you implement streaming
uv run uvicorn app.main:app --host 0.0.0.0 --port 8000
curl -s http://localhost:8000/healthz
```

## Next Steps
- Use `docs/specs/spec-chat-v1.md` + `docs/prompts/0102-implement-to-spec-chat-green.prompt.md` to implement the /chat slice.
- Then implement SSE using `spec-chat-streaming-sse-v1.md` + `0103-implement-to-spec-sse-green.prompt.md`.
- Add tools/guardrails + EDD smoke suite.
