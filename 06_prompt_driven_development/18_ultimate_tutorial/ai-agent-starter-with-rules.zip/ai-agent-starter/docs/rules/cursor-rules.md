# Project guardrails
- Python 3.12+, manage deps with uv (pyproject + uv.lock).
- Use OpenAI Agents SDK for agents/tools/sessions/handoffs/guardrails.
- FastAPI service with /healthz and /chat endpoints.
- Pydantic structured outputs; responses ≤ 1200 chars.
- No secrets in code or prompts; use .env + .env.sample.
- Tests first (pytest); offline by default; smallest green diff.

# Documentation & governance
- SDD specs in docs/specs; link each PR to at least one spec.
- PHRs (Prompt History Records) in docs/prompts with stage (architect/red/green/refactor/explainer).
- ADRs for consequential changes in docs/adr.
- PRs must be small, CI-green; “no green, no merge.”

# Agent defaults
- Primary CustomerAgent; optional ResearchAgent via handoff when intent=RESEARCH (confidence ≥ 0.7).
- Tools: calculator(expression), now(tz?). Prefer tools for math/time rather than guessing.
- Sessions per session_id; support SSE streaming on Accept: text/event-stream.

# Change policy
- Touch only files listed in the prompt/spec; keep diffs minimal.
- If tests break, propose a fix-only diff (no refactors).
- After each slice, produce an 8-bullet explainer and update PHR.
- For new protocols (e.g., streaming), write/attach an ADR and acceptance tests.

# Evaluation (EDD)
- Use promptfoo with a smoke suite for PR gating and full suite nightly.
- Include behavior tests for scope discipline and tool-first math/time policy.

# Security & privacy
- Redact PII; never paste secrets in prompts or code.
- Add privacy checks to PR checklist; keep logs and traces scrubbed.

# Performance & ops
- Keep endpoints deterministic in tests (mock external calls).
- Prefer SSE for simple streaming; evaluate WebSocket in ADRs for future versions.