---
id: 0102
title: Implement to Spec — /chat (non-streaming) — Green
stage: green
date: 2025-09-22
surface: vscode-codex|cursor
model: gpt-5-codex
repo_ref: <branch-or-commit>
scope_files:
  - app/main.py
  - app/guards/schemas.py
  - tests/test_chat_contract.py
links: { spec: "docs/specs/spec-chat-v1.md", adr: null }
acceptance:
  - Pass tests/test_chat_contract.py::test_chat_missing_user_message_returns_400_top_level_error_code
  - Pass tests/test_chat_contract.py::test_chat_happy_path_returns_chatreply_shape
constraints:
  - Minimal diff; only files listed
  - No new dependencies
  - Offline tests (mock external calls)
secrets_policy: "No secrets; use .env"
---

Implement strictly to the spec. Return **diff-only**, then ≤8-bullet explainer.