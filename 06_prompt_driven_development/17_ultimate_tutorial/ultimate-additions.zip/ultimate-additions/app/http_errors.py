from fastapi import JSONResponse

def bad_request(error_code: str):
    """Return a spec-compliant 400 with a top-level {"error_code": ...} body."""
    return JSONResponse(status_code=400, content={"error_code": error_code})