---
id: 0103
title: Implement to Spec — /chat SSE streaming — Green
stage: green
date: 2025-09-22
surface: vscode-codex|cursor
model: gpt-5-codex
repo_ref: <branch-or-commit>
scope_files:
  - app/main.py
  - app/streaming.py
  - tests/test_chat_streaming.py
links: { spec: "docs/specs/spec-chat-streaming-sse-v1.md", adr: "docs/adr/0002-streaming-protocol-choice.md" }
acceptance:
  - Pass tests/test_chat_streaming.py::test_streaming_sends_event_stream_headers
  - Pass tests/test_chat_streaming.py::test_streaming_emits_at_least_one_data_line_and_done
  - Preserve JSON fallback
constraints:
  - Minimal diff; only files listed
  - No new dependencies
  - Offline tests
secrets_policy: "No secrets; use .env"
---

Implement strictly to the spec. Output **diff-only**, then an 8-bullet explainer.