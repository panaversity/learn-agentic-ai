# Ultimate Additions Bundle

This bundle adds:
- **SDD specs** (`docs/specs/`), **PHRs** (`docs/prompts/`), **ADRs** (`docs/adr/`)
- **RED tests** for `/chat` and SSE (`tests/`)
- **Spec-compliant error helper** (`app/http_errors.py`)
- **EDD** via promptfoo (`promptfoo.config.yaml`, `evals/*`)
- **PR template** with **Spec compliance** checkbox
- **CI** example that runs an EDD smoke suite

## Merge steps
1. Copy these folders into your project root, preserving paths.
2. Merge the PR template with your own if needed.
3. Run:
   ```bash
   uv run pytest -q   # RED until you implement to spec
   ```
4. For EDD:
   ```bash
   npm i -g promptfoo
   uv run uvicorn app.main:app --host 0.0.0.0 --port 8000 &
   promptfoo eval --suite smoke
   ```

Generated: 2025-09-22