from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_chat_missing_user_message_returns_400_top_level_error_code():
    res = client.post("/chat", json={"session_id": "spec-red-1"})
    assert res.status_code == 400
    body = res.json()
    assert isinstance(body, dict)
    assert body.get("error_code") == "MISSING_USER_MESSAGE", "400 must be TOP-LEVEL {"error_code":...}"

def test_chat_happy_path_returns_chatreply_shape():
    res = client.post("/chat", json={"session_id": "spec-green-1", "user_message": "Hello!"})
    assert res.status_code == 200
    data = res.json()
    assert "text" in data and "handoff" in data and "used_tool" in data