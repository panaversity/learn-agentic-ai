from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from app.guards.schemas import ChatReply
from app.http_errors import bad_request
from app.streaming import to_sse

app = FastAPI(title="AI Agent Starter")

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

class ChatIn(BaseModel):
    session_id: str
    user_message: str | None = None

def _fake_tokenize(text: str):
    # Minimal stub tokenizer to satisfy SSE tests
    for tok in ["Hello", " from", " SSE"]:
        yield tok

@app.post("/chat")
def chat(payload: ChatIn, request: Request):
    # Spec-compliant 400 for missing user_message
    if not payload.user_message:
        return bad_request("MISSING_USER_MESSAGE")

    accept = request.headers.get("accept", "")
    if "text/event-stream" in accept.lower():
        # Implement SSE per spec
        tokens = _fake_tokenize(payload.user_message or "")
        return StreamingResponse(to_sse(tokens), media_type="text/event-stream")

    # JSON fallback (structured)
    reply = ChatReply(text="Hello! (non-streaming v1)", used_tool=None, handoff=False)
    return reply