---
id: 0299
title: Fix-only — make the smallest change to green
stage: maintenance
date: 2025-09-22
surface: cursor
model: gpt-5-codex
constraints:
  - Change only the lines necessary to pass the specified failing test
  - No refactors, no new deps
---

**Task:** Make the minimal change to pass the failing test shown in the last run output.
Return **diff-only** and nothing else.
