---
id: 0214
title: Refactor — extract streaming helpers and keep tests green
stage: refactor
date: 2025-09-22
surface: cursor
model: gpt-5-codex
links: { spec: "docs/specs/spec-chat-streaming-sse-v1.md" }
scope_files:
  - app/streaming.py
  - app/main.py
constraints:
  - Preserve public behavior; keep tests green
acceptance:
  - No changes in test outputs; code clearer
---

Extract or tighten streaming helpers (`to_sse`, etc.), remove duplication, keep behavior identical. Diff-only + ≤6-bullet rationale.
