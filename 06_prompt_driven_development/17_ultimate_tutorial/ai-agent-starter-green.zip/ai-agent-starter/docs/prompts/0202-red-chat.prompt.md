---
id: 0202
title: Red — add failing contract tests for /chat
stage: red
date: 2025-09-22
surface: cursor
model: gpt-5
links: { spec: "docs/specs/spec-chat-v1.md" }
scope_files:
  - tests/test_chat_contract.py
constraints:
  - Tests only; do not change app code
  - Offline; deterministic
acceptance:
  - tests/test_chat_contract.py contains the two contract tests as per the spec
---

Add/ensure **failing tests only** for `/chat` per `spec-chat-v1.md`:
- `test_chat_missing_user_message_returns_400_top_level_error_code`
- `test_chat_happy_path_returns_chatreply_shape`
Return **diff-only** for the test file.
