---
id: 0204
title: Refactor — tidy /chat internals without breaking tests
stage: refactor
date: 2025-09-22
surface: cursor
model: gpt-5-codex
links: { spec: "docs/spec-chat-v1.md" }
scope_files:
  - app/main.py
  - app/http_errors.py
constraints:
  - Keep public API and tests passing
  - No new deps
acceptance:
  - Tests remain green
---

Improve internal structure (readability, small helpers), but **preserve interfaces** and keep tests green.
Return **diff-only** and a short rationale (≤6 bullets).
