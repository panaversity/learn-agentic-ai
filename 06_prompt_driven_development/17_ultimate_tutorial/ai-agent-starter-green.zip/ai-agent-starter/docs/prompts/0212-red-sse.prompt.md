---
id: 0212
title: Red — add failing SSE tests
stage: red
date: 2025-09-22
surface: cursor
model: gpt-5
links: { spec: "docs/specs/spec-chat-streaming-sse-v1.md" }
scope_files:
  - tests/test_chat_streaming.py
constraints:
  - Tests only; offline; deterministic
acceptance:
  - Two failing tests enforcing headers and event lines
---

Add/ensure **failing** SSE tests:
- `test_streaming_sends_event_stream_headers`
- `test_streaming_emits_at_least_one_data_line_and_done`
Return **diff-only**.
