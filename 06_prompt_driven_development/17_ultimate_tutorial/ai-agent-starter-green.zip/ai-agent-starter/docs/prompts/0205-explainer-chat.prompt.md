---
id: 0205
title: Explainer — /chat (non-streaming) slice summary
stage: explainer
date: 2025-09-22
surface: cursor
model: gpt-5
links: { spec: "docs/specs/spec-chat-v1.md" }
---

Summarize in ≤8 bullets:
- Files touched and why
- Public contracts (request/response, errors)
- Edge cases handled
- Trade-offs or future work
