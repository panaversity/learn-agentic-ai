# VS Code + Codex — Prompting House Rules (2025)

**Project guardrails**
- Python 3.12+, uv for deps; OpenAI Agents SDK for agents/tools/sessions/handoffs/guardrails.
- FastAPI with /healthz and /chat; structured outputs with Pydantic; length ≤ 1200 chars.
- Tests first (pytest); minimal diffs; offline tests by default.

**Governance**
- SDD specs in docs/specs; PHRs in docs/prompts; ADRs in docs/adr.
- PRs must link spec + PHR (+ ADR if consequential). CI runs ruff + pytest (+ EDD smoke if configured).

**PDD Loop**
1) Architect prompt (micro-spec) → 2) Red (tests only) → 3) Green (smallest diff) → 4) Refactor (keep tests green) → 5) Explain (≤8 bullets) → 6) Record (PHR/ADR) → 7) Share (PR).

**Agent defaults**
- CustomerAgent primary; ResearchAgent via handoff when intent=RESEARCH, confidence ≥0.7.
- Tools: calculator(expression), now(tz?); prefer tools for math/time.

**Streaming**
- If Accept: text/event-stream → SSE with `data:<token>\n\n` and final `data:[DONE]`.
- Otherwise JSON ChatReply fallback.

**EDD (promptfoo)**
- Add smoke suite (`evals/behavior/*.yaml`) to PR gate; full suite nightly.

**Change policy**
- Touch only files listed in the prompt/spec; minimal diffs; fix-only if tests fail.
- No secrets in prompts/code; use .env. Provide curl examples in README for any new surface.