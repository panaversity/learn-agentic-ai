# Rules Bundles (Cursor + Codex)
Generated 2025-09-22.

- **Cursor**: paste `cursor-rules.md` (or JSON content) into *Cursor → Settings → Rules for AI*.
- **Codex (VS Code)**: paste `codex-rules.md` at the top of your task prompts or keep it checked into the repo for team consistency.

These guardrails encode SDD×PDD×TDD×EDD workflow and align with the specs, PHRs, ADRs, CI, and PR template in this starter.