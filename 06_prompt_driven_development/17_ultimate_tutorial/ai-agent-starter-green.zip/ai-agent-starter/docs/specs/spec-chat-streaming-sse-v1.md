# Spec: Chat Streaming via SSE (v1)
Version: v1
Status: Accepted
Owner: Platform Team
Linked ADRs: [ADR-0002: streaming-protocol-choice]

## 1) Scope & Outcomes
- Add token streaming for `/chat` using Server-Sent Events (SSE).

## 2) Interfaces & Contracts
**Trigger**
- If request header `Accept: text/event-stream`, stream tokens; else JSON fallback.

**Protocol**
- Content-Type: text/event-stream
- Event lines: `data:<token>\n\n`
- Terminator: `data:[DONE]\n\n`

**Fallback**
- Preserve JSON ChatReply when not using SSE.

## 3) Agent Behavior & Policies
- Runner yields token chunks; server emits SSE.
- Sessions preserved by `session_id`.

## 4) Acceptance (Tests)
- test_streaming_sends_event_stream_headers
- test_streaming_emits_at_least_one_data_line_and_done
- JSON fallback remains intact.

## 5) Ops & Constraints
- No new runtime deps; streaming mocked in tests.

## 6) Change Control
- ADR documents protocol choice; PR links PHR/ADR.

*Last updated: 2025-09-22*