# PR Title

## Summary
What changed and why.

## Linked Spec(s)
- Spec: `docs/specs/<spec-file>.md` (version & status)
- ADRs: `docs/adr/<id>-*.md` (if applicable)
- PHRs: `docs/prompts/<id>-*.prompt.md` (architect/red/green/refactor/explainer)

## Test Plan
Commands, screenshots, or curl showing success & error paths.
- `uv run pytest -q`
- (optional) `promptfoo eval --suite smoke` results

## Risks & Rollback
Known risks and how to revert safely.

---

## Checklist
- [ ] **Small diff** (scoped to files listed in PHR/spec)
- [ ] **Spec compliance** — links above; contracts/behaviors/constraints implemented as written; **spec acceptance tests present & passing**; (if configured) **EDD smoke** passes
- [ ] **CI green** (ruff + pytest; EDD if configured)
- [ ] **PHR linked** (the exact prompts used)
- [ ] **ADR linked** (for consequential design decisions)
- [ ] **No secrets** (uses `.env`; no keys in code or prompts)
- [ ] **Docs updated** (README/examples if public surface changed)