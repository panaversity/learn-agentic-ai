# ADR-0002: Streaming Protocol Choice
- **Status:** Accepted
- **Date:** 2025-09-22

## Context
We need token streaming for `/chat`. Options: SSE, WebSocket, Long-polling.

## Options
### SSE
- Pros: Simple over HTTP, reverse proxies friendly, easy client.
- Cons: One-way; some proxies may buffer.

### WebSocket
- Pros: Full-duplex, interactive UIs.
- Cons: Infra complexity, LB/proxy nuances.

### Long-poll
- Pros: Simple, broad compatibility.
- Cons: Inefficient; higher latency/server load.

## Decision
Choose **SSE** for v1 due to simplicity and HTTP friendliness. Keep WebSocket as a future option.

## Consequences
- Implement SSE handler and tests; preserve JSON fallback.

## References
- docs/specs/spec-chat-streaming-sse-v1.md
- PHR ids for streaming slice