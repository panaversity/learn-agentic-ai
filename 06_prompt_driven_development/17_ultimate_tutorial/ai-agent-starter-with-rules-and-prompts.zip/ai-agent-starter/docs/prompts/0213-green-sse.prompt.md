---
id: 0213
title: Green — implement SSE to spec
stage: green
date: 2025-09-22
surface: cursor
model: gpt-5-codex
links: { spec: "docs/specs/spec-chat-streaming-sse-v1.md", adr: "docs/adr/0002-streaming-protocol-choice.md" }
scope_files:
  - app/main.py
  - app/streaming.py
  - tests/test_chat_streaming.py
constraints:
  - Minimal diff; only listed files
  - No new dependencies
  - Offline tests
acceptance:
  - Both SSE tests pass; JSON fallback intact
---

Implement **SSE** per the spec:
- Emit `data:<token>\n\n` events and final `data:[DONE]\n\n`.
- Ensure `Content-Type: text/event-stream` when streaming.
Return **diff-only**, then an ≤8‑bullet explainer (headers, event shape, fallback).
