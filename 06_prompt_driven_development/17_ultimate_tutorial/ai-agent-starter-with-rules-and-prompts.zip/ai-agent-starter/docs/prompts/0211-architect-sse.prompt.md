---
id: 0211
title: Architect — /chat SSE streaming to spec
stage: architect
date: 2025-09-22
surface: cursor
model: gpt-5
links: { spec: "docs/specs/spec-chat-streaming-sse-v1.md", adr: "docs/adr/0002-streaming-protocol-choice.md" }
scope_files:
  - app/main.py
  - app/streaming.py
  - tests/test_chat_streaming.py
constraints:
  - Minimal diff; only listed files
  - Offline tests
acceptance:
  - Map how to satisfy SSE headers and event format
  - Plan to preserve JSON fallback
---

Design the smallest change to add **SSE** per the spec:
- Trigger: `Accept: text/event-stream`
- Headers: `Content-Type: text/event-stream`
- Events: `data:<token>\n\n` and final `data:[DONE]\n\n`
Produce a brief implementation plan and verify acceptance mapping. No code yet.
