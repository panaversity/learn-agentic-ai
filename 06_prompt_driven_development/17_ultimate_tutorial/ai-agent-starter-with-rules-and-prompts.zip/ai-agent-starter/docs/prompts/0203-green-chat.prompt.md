---
id: 0203
title: Green — implement /chat to spec
stage: green
date: 2025-09-22
surface: cursor
model: gpt-5-codex
links: { spec: "docs/specs/spec-chat-v1.md" }
scope_files:
  - app/main.py
  - app/guards/schemas.py
  - tests/test_chat_contract.py
constraints:
  - Minimal diff; only listed files
  - No new dependencies
  - Offline tests
acceptance:
  - Pass both tests in tests/test_chat_contract.py
---

Implement strictly to `spec-chat-v1.md`:
- For missing `user_message`, return **top-level** `{"error_code":"MISSING_USER_MESSAGE"}` with HTTP 400 (not under `detail`).
- On success, return `ChatReply` with `text`, `handoff`, and `used_tool` fields.
Return **diff-only**, then a ≤8‑bullet explainer.
