---
id: 0215
title: Explainer — /chat SSE slice summary
stage: explainer
date: 2025-09-22
surface: cursor
model: gpt-5
links: { spec: "docs/specs/spec-chat-streaming-sse-v1.md", adr: "docs/adr/0002-streaming-protocol-choice.md" }
---

Summarize in ≤8 bullets:
- Trigger/headers/event format
- Fallback behavior
- Files touched
- Risks and monitoring tips
