---
id: 0201
title: Architect — /chat (non-streaming) to spec
stage: architect
date: 2025-09-22
surface: cursor
model: gpt-5
links: { spec: "docs/specs/spec-chat-v1.md", adr: null }
scope_files:
  - app/main.py
  - app/guards/schemas.py
  - tests/test_chat_contract.py
constraints:
  - Minimal diff; only files listed
  - Offline tests; no network calls
  - No new dependencies
acceptance:
  - Pass tests/test_chat_contract.py::test_chat_missing_user_message_returns_400_top_level_error_code
  - Pass tests/test_chat_contract.py::test_chat_happy_path_returns_chatreply_shape
---

**Goal:** Design a minimal `/chat` implementation strictly conforming to `docs/specs/spec-chat-v1.md`.
**Deliverables:**
1) A short plan of the smallest code changes.
2) Any clarifying assumptions (none that contradict the spec).
3) A checklist of acceptance criteria mapped to the spec.
4) A diff plan (which files/functions to touch).
Do **not** write code yet; produce the plan and confirm scope.
