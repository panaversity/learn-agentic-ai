
from typing import Iterable

def to_sse(chunks: Iterable[str]):
    for c in chunks:
        yield f"data:{c}\n\n"
    yield "data:[DONE]\n\n"
