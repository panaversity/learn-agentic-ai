
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
from app.guards.schemas import ChatReply
from app.http_errors import bad_request

app = FastAPI(title="AI Agent Starter")

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

class ChatIn(BaseModel):
    session_id: str
    user_message: str | None = None

@app.post("/chat", response_model=ChatReply)
def chat(payload: ChatIn, request: Request):
    # Spec-compliant 400 for missing user_message
    if not payload.user_message:
        return bad_request("MISSING_USER_MESSAGE")

    # SSE branch (stub): honor Accept header but emit minimal SSE
    accept = request.headers.get("accept", "")
    if "text/event-stream" in accept.lower():
        # Defer to streaming in real implementation; here return JSON fallback until GREEN step
        # To fully pass SSE tests, implement StreamingResponse with text/event-stream and to_sse()
        return ChatReply(text="(SSE not yet implemented)", used_tool=None, handoff=False)

    # JSON fallback
    return ChatReply(text="Hello! (non-streaming v1)", used_tool=None, handoff=False)
