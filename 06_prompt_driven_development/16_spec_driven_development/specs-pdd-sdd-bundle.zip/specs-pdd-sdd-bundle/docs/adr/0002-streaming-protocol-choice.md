# ADR-0002: Streaming Protocol Choice
- **Status:** Draft
- **Date:** 2025-09-22

## Context
We need token streaming for `/chat`. Options considered: **SSE**, **WebSocket**, **Long-polling**.

## Options
- **SSE**
  - Pros: Simple over HTTP, easy to proxy, minimal client code.
  - Cons: One-way (server→client), some legacy proxies buffer.
- **WebSocket**
  - Pros: Full-duplex; good for interactive UIs.
  - Cons: More infra complexity; load balancer nuances.
- **Long-polling**
  - Pros: Simple, widely compatible.
  - Cons: Inefficient; higher latency and server load.

## Decision
Choose **SSE** for v1 due to simplicity and HTTP friendliness. Keep WebSocket as a future option.

## Consequences
- Add SSE handler; preserve JSON fallback.
- Docs and tests for headers + event format.

## References
- `docs/specs/spec-chat-streaming-sse-v1.md`
- PHR ids associated with the streaming iteration.