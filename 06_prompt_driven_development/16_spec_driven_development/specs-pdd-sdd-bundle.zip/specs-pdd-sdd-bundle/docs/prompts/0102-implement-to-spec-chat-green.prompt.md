---
id: 0102
title: Implement to Spec — /chat (non-streaming) — Green
stage: green
date: 2025-09-22
surface: vscode-codex|cursor
model: gpt-5-codex
repo_ref: <branch-or-commit>
scope_files:
  - app/main.py
  - app/guards/schemas.py
  - tests/test_chat_contract.py
links: { adr: null, issue: null, pr: null, spec: "docs/specs/spec-chat-v1.md" }
acceptance:
  - Pass tests/test_chat_contract.py::test_chat_missing_user_message_returns_400
  - Pass tests/test_chat_contract.py::test_chat_happy_path_returns_chatreply_shape
constraints:
  - Minimal diff; touch only the files listed
  - No new dependencies
  - Tests offline (mock external calls)
secrets_policy: "No secrets in code or prompts; use .env"
---

You are implementing **exactly** what is specified in `docs/specs/spec-chat-v1.md`.

**Task**
- Make the smallest code changes needed to satisfy the spec and pass the acceptance tests.
- Return **diff-only** output.

**After the diff**
- Provide an explainer in ≤8 bullets covering: files touched, public interfaces, edge cases, and trade-offs.