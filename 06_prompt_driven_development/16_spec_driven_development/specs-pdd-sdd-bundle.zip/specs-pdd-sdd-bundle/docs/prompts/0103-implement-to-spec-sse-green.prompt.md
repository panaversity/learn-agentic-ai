---
id: 0103
title: Implement to Spec — /chat SSE streaming — Green
stage: green
date: 2025-09-22
surface: vscode-codex|cursor
model: gpt-5-codex
repo_ref: <branch-or-commit>
scope_files:
  - app/main.py
  - app/streaming.py
  - tests/test_chat_streaming.py
links: { adr: "docs/adr/0002-streaming-protocol-choice.md", issue: null, pr: null, spec: "docs/specs/spec-chat-streaming-sse-v1.md" }
acceptance:
  - Pass tests/test_chat_streaming.py::test_streaming_sends_event_stream_headers
  - Pass tests/test_chat_streaming.py::test_streaming_emits_at_least_one_data_line
  - Preserve non-streaming JSON fallback
constraints:
  - Minimal diff; touch only the files listed
  - No new dependencies
  - Tests offline
secrets_policy: "No secrets in code or prompts; use .env"
---

Implement SSE streaming strictly per `docs/specs/spec-chat-streaming-sse-v1.md`.

**Task**
- Add SSE behavior when `Accept: text/event-stream`, emitting `data:<token>\n\n` and final `data:[DONE]\n\n`.
- Keep existing JSON fallback for non-SSE requests.
- Output **diff-only**.

**After the diff**
- Provide an 8-bullet explainer (headers, event shape, fallbacks, tests).