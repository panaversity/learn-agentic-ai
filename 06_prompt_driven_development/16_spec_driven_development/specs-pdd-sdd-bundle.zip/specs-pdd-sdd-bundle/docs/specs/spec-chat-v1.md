# Spec: Chat Endpoint (v1)
Version: v1
Status: Accepted
Owner: Platform Team
Linked ADRs: [ADR-0002: streaming-protocol-choice (planned)]

## 1) Scope & Outcomes
- Provide a minimal chat endpoint that accepts a `session_id` and a `user_message` and returns a structured reply.
- Persistence is **in-memory** per session for v1.
- Non-goals: auth, rate limiting, persistence to DB, tracing (future ADRs).

## 2) Interfaces & Contracts
**Endpoint**
- `POST /chat` with JSON `{ session_id: str, user_message: str }`

**Response (structured)**
- `ChatReply`:
  - `text: str`
  - `used_tool?: str | null`
  - `handoff: bool`

**Errors**
- `400` with JSON `{ "error_code": "MISSING_USER_MESSAGE" }` when `user_message` is empty or missing.
- Content-Type must be `application/json`.

## 3) Agent Behavior & Policies
- Primary agent: **CustomerAgent**; answers concisely; output length ≤1200 chars.
- Prefer tools for **math/time** (`calculator`, `now`) rather than guessing.
- Sessions: maintain conversation state keyed by `session_id`.
- Guardrails: response validated against `ChatReply` schema; on failure, single retry then friendly error.

## 4) Acceptance (Tests)
- **Contract tests**
  - `test_chat_missing_user_message_returns_400`: Given POST without `user_message` → HTTP 400 and body `{"error_code":"MISSING_USER_MESSAGE"}`.
  - `test_chat_happy_path_returns_chatreply_shape`: Given valid input → HTTP 200 with object containing keys `text` and `handoff` (and optional `used_tool`).
- **Unit tests**
  - Pydantic validation for `ChatReply` shape.

## 5) Ops & Constraints
- Offline tests by default (mock model/tool calls).
- No secrets in code; use `.env` for `OPENAI_API_KEY`.

## 6) Change Control
- PR must link PHR IDs and any ADR updates.
- Version bump and migration notes if schema changes.
- CI gates: ruff + pytest (and EDD smoke when enabled).

*Last updated: 2025-09-22*