# Spec: Chat Streaming via SSE (v1)
Version: v1
Status: Draft
Owner: Platform Team
Linked ADRs: [ADR-0002: streaming-protocol-choice]

## 1) Scope & Outcomes
- Add token streaming for `/chat` using **Server-Sent Events (SSE)** when requested by the client.

## 2) Interfaces & Contracts
**Trigger**
- If request header `Accept: text/event-stream`, stream tokens via SSE; otherwise return the JSON `ChatReply` (non-streaming fallback).

**Protocol**
- Response header: `Content-Type: text/event-stream`
- Event format (one token per event):
  - `data:<token>\n\n`
- Terminator event:
  - `data:[DONE]\n\n`

**Fallback**
- If `Accept` is not SSE, preserve the existing JSON `ChatReply` response.

## 3) Agent Behavior & Policies
- The underlying runner should produce token chunks; server emits them as SSE events.
- Maintain session semantics (same `session_id`).

## 4) Acceptance (Tests)
- `test_streaming_sends_event_stream_headers`: Response content-type starts with `text/event-stream`.
- `test_streaming_emits_at_least_one_data_line`: Body contains at least one line starting with `"data:"` and ends with `"data:[DONE]"`.
- Non-streaming regression: JSON fallback remains intact.

## 5) Ops & Constraints
- No new runtime dependencies for v1.
- Mock streaming in unit tests to stay offline.

## 6) Change Control
- ADR-0002 documents SSE vs WebSocket vs long-poll decision.
- PR must link PHR IDs and ADR-0002.

*Last updated: 2025-09-22*