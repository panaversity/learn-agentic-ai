# GPS Engineering — One‑Pager

**Definition**  
**Governed Prompt Software Engineering**: A practical method for building AI‑accelerated systems that combines **SDD (specs)**, **PDD (prompts)**, **TDD**, **EDD**, **ADRs**, **PHRs**, and **PRs** into one disciplined loop.

**Loop**
- **Specify** a thin slice (contract + acceptance).
- **Prompt** the code via sequenced PHRs.
- **Test** first (RED), then **Green** smallest diff.
- **Evaluate** behavior (promptfoo) to prevent drift.
- **Record** decisions (ADRs).
- **Review** via small, CI‑gated PR with **Spec‑Compliance**.

**Why it works**
- Specs prevent prompt drift.
- Tests/evals convert intent into executable truth.
- ADR/PR keep choices auditable.
- Prompts make AI the typist; humans remain the engineers.

**Where to start**
- `docs/specs/spec-chat-v1.md`
- `docs/prompts/0201-…architect-chat.prompt.md`
- `tests/test_chat_contract.py`
- `promptfoo.config.yaml` (smoke suite)
