# Cursor — Rules for AI (GPS Engineering, 2025)

**Definition**: **GPS Engineering** = **SDD × PDD × TDD × EDD × ADR × PHR × PR**

**Guardrails**
- Python 3.12+, **uv** for deps; **OpenAI Agents SDK** for agents/tools/sessions/handoffs/guardrails.
- FastAPI service with `/healthz` and `/chat`.
- Pydantic structured outputs; responses ≤ 1200 chars.
- **No secrets** in code/prompts; use `.env` + `.env.sample`.
- **Smallest change to green**; tests offline by default.

**Process (GPS Loop)**
1) **Specify (SDD)** → docs/specs  
2) **Prompt (PDD)** → PHRs in docs/prompts (Architect/Red/Green/Refactor/Explainer)  
3) **Test (TDD)** → pytest contract/unit tests  
4) **Evaluate (EDD)** → promptfoo smoke on PRs, full nightly  
5) **Record (ADR)** → docs/adr for consequential choices  
6) **Review (PR)** → small, CI-green, **Spec-Compliance** required

**Agent defaults**
- CustomerAgent primary; ResearchAgent handoff on intent=RESEARCH (confidence ≥0.7).
- Tools: `calculator(expression)`, `now(tz?)`; **tool‑first** for math/time.
- Sessions per `session_id`; SSE on `Accept: text/event-stream` → `data:<token>\n\n`, `data:[DONE]\n\n`.

**Change policy**
- Touch only files listed in the prompt/spec; produce **diff‑only** patches and an ≤8‑bullet explainer.
