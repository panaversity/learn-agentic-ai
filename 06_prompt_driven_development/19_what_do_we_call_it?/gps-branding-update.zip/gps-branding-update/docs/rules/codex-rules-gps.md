# VS Code + Codex — Prompting House Rules (GPS Engineering, 2025)

**GPS Engineering** = **SDD × PDD × TDD × EDD × ADR × PHR × PR**

**Use these defaults in every task prompt**
- Implement to a **spec** (`docs/specs/...md`), not vibes.
- Add/keep **tests** green (pytest); offline by default.
- Keep diffs **minimal**; if a test fails, submit a **fix‑only** diff.
- Capture the prompt as a **PHR** in `docs/prompts/`.
- Link **ADR/PHR/Spec** in PR and tick **Spec‑Compliance**.

**Agent & API**
- CustomerAgent, optional ResearchAgent via handoff.
- SSE protocol per spec when `Accept: text/event-stream`.
- Pydantic models; guardrails for output shape/length.

**EDD**
- Run `promptfoo eval --suite smoke` for PRs; full suite nightly.
