# AI Agent Starter — **GPS Engineering** (Governed Prompt Software Engineering)

**GPS Engineering** = **SDD × PDD × TDD × EDD × ADR × PHR × PR**  
*“Build with AI, but with a suit on.”*

### What is GPS Engineering?
A disciplined method that uses **Specs** to define “done,” **Prompts** to generate code, **Tests/Evals** to guard quality, and **ADRs/PRs** to capture decisions and gate changes.

### The GPS Loop
1. **Specify (SDD)** → Thin, testable spec per slice  
2. **Prompt (PDD)** → Architect → Red → Green → Refactor → Explainer (PHRs)  
3. **Test (TDD)** → Unit/contract tests (offline)  
4. **Evaluate (EDD)** → Behavior suites (promptfoo)  
5. **Record (ADR)** → Why this way, not that  
6. **Review (PR)** → Small, CI-gated; **Spec-Compliance** checkbox

This repo ships with:
- **Specs**: `docs/specs/` for `/chat` JSON and SSE  
- **Prompts (PHRs)**: `docs/prompts/` including Cursor Composer prompts  
- **ADRs**: `docs/adr/0002-streaming-protocol-choice.md`  
- **Tests**: `tests/` (contract + SSE)  
- **EDD**: `promptfoo.config.yaml`, `evals/behavior/*.yaml`  
- **Rules**: `docs/rules/` for Cursor and Codex  
- **PR Template**: `.github/PULL_REQUEST_TEMPLATE.md` with **Spec compliance** gate

> Tip: Rename your internal method to **GPS Engineering** across docs and onboarding.

_Last updated: 2025-09-22_
