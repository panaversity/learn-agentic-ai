# PR Title — GPS Engineering

## Summary
What changed and why.

## Linked Spec(s)
- Spec: `docs/specs/<spec-file>.md` (version & status)
- ADRs: `docs/adr/<id>-*.md` (if applicable)
- PHRs: `docs/prompts/<id>-*.prompt.md` (architect/red/green/refactor/explainer)

## Test Plan
- `uv run pytest -q`
- (optional) `promptfoo eval --suite smoke` results
- curl or screenshots for key endpoints

## Risks & Rollback
Known risks; how to revert.

---

## Checklist
- [ ] **Small diff** (scoped to files listed in PHR/spec)
- [ ] **Spec compliance** — contracts/behaviors/constraints implemented as written; spec acceptance tests passing; (if configured) **EDD smoke** passes
- [ ] **CI green** (ruff + pytest; EDD if configured)
- [ ] **PHR linked**
- [ ] **ADR linked** (if consequential change)
- [ ] **No secrets** (uses `.env`)
- [ ] **Docs updated** (README/examples if public surface changed)
