# PR: Bootstrap service + /chat contract (non-streaming) — Red → Green

## Summary
This PR bootstraps the service and introduces the **/chat** non-streaming contract with tests-first (Red) followed by minimal implementation (Green). It also adds PHR examples and stubs for agents, guards, and streaming.

## Prompt History (PHR) References
- Architect: `docs/prompts/0001-healthz-architect.prompt.md`, `docs/prompts/0003-chat-architect.prompt.md`
- Green: `docs/prompts/0002-healthz-green.prompt.md`, `docs/prompts/0004-chat-green.prompt.md`

## ADRs
- Upcoming: `docs/adr/0002-streaming-protocol-choice.md` (draft in this PR)

## Changes
- Minimal FastAPI app (`/healthz`)
- Failing tests for `/chat` (contract) and SSE (to come)
- Stubs for:
  - `app/agents/core.py` (session store + placeholders)
  - `app/agents/tools.py`, `app/agents/customer.py`, `app/agents/research.py`
  - `app/guards/schemas.py`, `app/guards/rules.py`
  - `app/streaming.py` (SSE helper)
- Docs:
  - PHR examples in `docs/prompts/`
  - Diagrams & iteration guide in `docs/AI-FIRST-PLAYBOOK-DIAGRAMS-PHRS.md`
  - PR template under `.github/`
- CI: basic lint + test workflow

## Test Plan
```bash
pytest -q
# Expect RED initially for /chat and SSE until green steps:
# - tests/test_chat_contract.py::test_chat_missing_user_message_returns_400
# - tests/test_chat_contract.py::test_chat_happy_path_returns_chatreply_shape
# - tests/test_chat_streaming.py::test_chat_streaming_sse_headers_and_events  # stays red until SSE slice
```
After implementing the **green** step for `/chat`, the first two tests should pass.

## Risks & Rollback
- Low risk; scaffolding only. Rollback by reverting this PR.
- No external network calls; tests are offline.

## Checklist
- [x] Small, focused diff
- [x] Tests added/updated; CI is expected to fail until `/chat` green step lands
- [x] ADR draft for streaming protocol added
- [x] No secrets in code or prompts
