---
id: 0001
title: Healthcheck Endpoint
stage: architect
date: 2025-09-21
surface: cursor-composer
model: gpt-5-codex
repo_ref: main
scope_files:
  - app/main.py
  - tests/test_healthz.py
links:
  adr: null
  issue: null
  pr: null
acceptance:
  - Given GET /healthz Then HTTP 200
  - And response body equals {"status":"ok"}
constraints:
  - minimal diff, no new deps
  - offline tests (mocks only)
out_of_scope:
  - auth, db, tracing
secrets_policy: "No secrets; use .env"
labels: [api, healthz]
---

Create GET `/healthz` returning `{"status":"ok"}`. Add `tests/test_healthz.py::test_healthz_ok`. Update README with a curl example. Keep the diff minimal and avoid unrelated refactors.

### Outcome
- Files changed: app/main.py, tests/test_healthz.py, README.md
- Tests added: tests/test_healthz.py::test_healthz_ok
- Next prompts: PHR-0002 (green: implement minimal route)
- Notes: None
