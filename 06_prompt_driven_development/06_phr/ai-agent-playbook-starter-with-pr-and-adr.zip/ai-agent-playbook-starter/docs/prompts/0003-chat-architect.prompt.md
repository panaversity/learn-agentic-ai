---
id: 0003
title: /chat Contract (Non-Streaming)
stage: architect
date: 2025-09-21
surface: cursor-composer
model: gpt-5-codex
repo_ref: feat/chat-endpoint
scope_files:
  - app/main.py
  - app/agents/core.py
  - app/guards/schemas.py
  - tests/test_chat_contract.py
links:
  adr: null
  issue: null
  pr: null
acceptance:
  - POST /chat with {session_id, user_message} returns 200 and ChatReply {text, used_tool?, handoff: bool}
  - POST /chat missing user_message returns 400 with error_code=MISSING_USER_MESSAGE
constraints:
  - minimal diff; offline tests; no new deps
  - in-memory sessions keyed by session_id
out_of_scope:
  - SSE streaming
  - external network calls (mock model/tool invocation)
secrets_policy: "No secrets; use .env"
labels: [api, contract, agents]
---

Design `/chat` (non-streaming). Define ChatReply schema and validation. Add contract tests for 200 and 400 cases. Prepare stubs in `app/agents/core.py` (runner/session), `app/guards/schemas.py` (ChatReply).

### Outcome
- Files changed: tests/test_chat_contract.py (added failing tests)
- Tests added: test_chat_missing_user_message_returns_400, test_chat_happy_path_returns_chatreply_shape
- Next prompts: PHR-0004 (green: minimal implementation to pass tests)
- Notes: Keep external calls mocked; no network
