# ADR-0002: Streaming Protocol Choice for `/chat`
- **Status:** Draft
- **Date:** 2025-09-21

## Context
We need to stream model tokens to clients from the `/chat` endpoint. Options include **Server-Sent Events (SSE)**, **WebSocket**, and **HTTP long-polling**. Constraints: keep the runtime simple, minimize deps, remain proxy/CDN friendly, and support curl/demoability.

## Options
- **A) Server-Sent Events (SSE)**
  - Pros: Simple (HTTP/1), easy to demo with curl, CDN/proxy friendly, fits token streaming.
  - Cons: One-way from server to client; limited binary support; some intermediaries buffer.
- **B) WebSocket**
  - Pros: Full-duplex; good for interactive UIs; broad library support.
  - Cons: More infra complexity (stateful), tougher to demo, sometimes blocked by proxies.
- **C) Long-polling**
  - Pros: Works everywhere, no special infra.
  - Cons: Inefficient for token streams; higher latency and server load.

## Decision (Proposed)
Choose **SSE** for initial token streaming on `/chat` with a JSON fallback. This balances simplicity, compatibility, and developer ergonomics. We can layer WS later for interactive use-cases.

## Consequences
- Positive: Minimal code + infra complexity; easy local demos and logs; curl-friendly.
- Negative: No client-to-server backchannel; buffering on some proxies (mitigated by headers/keep-alive).
- Follow-ups: Provide example SSE client; document headers and retry behavior.

## References
- Related PHRs: PHR-0009 (architect SSE), PHR-0010 (red), PHR-0011 (green)
- PR: This document introduced in `docs/pr/0001-bootstrap-and-chat-contract.md`
