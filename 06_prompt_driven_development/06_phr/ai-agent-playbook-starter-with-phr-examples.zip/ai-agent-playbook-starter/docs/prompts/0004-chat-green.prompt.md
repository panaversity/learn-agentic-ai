---
id: 0004
title: /chat Minimal Implementation (Non-Streaming)
stage: green
date: 2025-09-21
surface: cursor-composer
model: gpt-5-codex
repo_ref: feat/chat-endpoint
scope_files:
  - app/main.py
  - app/agents/core.py
  - app/guards/schemas.py
links:
  adr: null
  issue: null
  pr: null
acceptance:
  - tests/test_chat_contract.py::test_chat_missing_user_message_returns_400 passes
  - tests/test_chat_contract.py::test_chat_happy_path_returns_chatreply_shape passes
constraints:
  - smallest diff to green; no new deps; keep logic simple
  - mock model/tool invocation (no network)
out_of_scope:
  - SSE streaming
  - guardrails beyond shape
secrets_policy: "No secrets; use .env"
labels: [api, contract, agents]
---

Implement the smallest changes to pass both `/chat` contract tests. Provide a stubbed response that fits ChatReply and wire session lookup via `get_session` in `app/agents/core.py`. Keep code minimal and focused on the tests.

### Outcome
- Files changed: app/main.py, app/agents/core.py, app/guards/schemas.py
- Tests added: none (greens achieved)
- Next prompts: PHR-0005 (architect SSE), ADR for streaming choice
- Notes: Ready to extend with SSE
