from .schemas import ChatReply

MAX_LEN = 1200

def validate_reply(reply: ChatReply) -> ChatReply:
    if not reply.text or len(reply.text) > MAX_LEN:
        raise ValueError("invalid reply length")
    return reply