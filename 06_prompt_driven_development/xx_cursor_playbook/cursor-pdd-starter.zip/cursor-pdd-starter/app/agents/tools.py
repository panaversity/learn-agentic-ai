from typing import Optional

def calculator(expression: str) -> str:
    raise NotImplementedError

def now(tz: Optional[str] = None) -> str:
    raise NotImplementedError