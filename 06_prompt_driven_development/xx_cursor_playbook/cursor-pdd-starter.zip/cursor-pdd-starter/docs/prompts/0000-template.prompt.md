---
id: 0000
title: <slice-title>
stage: architect
date: YYYY-MM-DD
surface: cursor-composer
model: gpt-5-codex
repo_ref: <branch-or-commit>
scope_files: [<paths>]
links: { adr: null, issue: null, pr: null }
acceptance:
  - Given/When/Then checks
constraints:
  - minimal diff; no new deps
out_of_scope: []
secrets_policy: "No secrets in prompts; use .env"
labels: []
---

<PASTE THE EXACT PROMPT YOU USED>

### Outcome
- Files changed:
- Tests added:
- Next prompts:
- Notes: