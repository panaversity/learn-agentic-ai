# Cursor — Rules for AI

- Python 3.12+, uv deps; pyproject + uv.lock
- OpenAI Agents SDK for agents/tools/sessions/handoffs/guardrails
- FastAPI with /healthz and /chat
- Tests first (pytest), offline; minimal diffs
- Pydantic structured outputs; reply length ≤ 1200
- No secrets in code/prompts; use .env + .env.sample
- Docker: uv multi-stage; non-root

Docs & governance
- PHRs in docs/prompts (architect/red/green/refactor/explainer)
- ADRs in docs/adr for consequential choices
- PRs link PHRs + ADRs; CI runs ruff + pytest; no green, no merge

Agents
- CustomerAgent primary; ResearchAgent via intent handoff
- Tools: calculator(expression), now(tz?)
- Sessions per session_id; SSE streaming with JSON fallback

Change policy
- Touch only files listed in prompt; minimal diff
- If tests break, fix-only diff
- Explain changes in ≤8 bullets per slice