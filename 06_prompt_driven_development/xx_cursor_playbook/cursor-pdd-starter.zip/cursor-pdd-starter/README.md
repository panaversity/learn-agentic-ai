# Cursor PDD Starter

AI-first workflow for Prompt-Driven Development (PDD) in Cursor with TDD, ADRs, PR discipline, and PHRs. Uses uv for deps.

## Quickstart
```bash
uv venv && source .venv/bin/activate
uv sync
uv run pytest -q
uv run uvicorn app.main:app --host 0.0.0.0 --port 8000
```